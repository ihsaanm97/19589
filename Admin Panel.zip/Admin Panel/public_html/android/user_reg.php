<?php

include("db.php");
$conn = new mysqli($h, $u, $p, $d);

function emailExist($email,$phone,$conn){

	$query = "SELECT email, phone FROM users;";
	$result = $conn->query($query);
	while($row = $result->fetch_assoc()){
		if($email==$row['email'] || $phone==$row['phone']){
			return true;
		}
	}
	return false;
}

if(isset($_GET['register'])){

	$name = $_POST['name'];
	$email = $_POST['email'];
	$phone = $_POST['number'];
	$collid = $_POST['collid'];
	$deptid = $_POST['deptid'];
	$ctype = $_POST['ctype'];
	$password = $_POST['pass'];
	$token = $_POST['token'];
	
	$sql = "INSERT INTO users VALUES(null,'$name','$email','$phone','$collid','$deptid','M','$password','$ctype','$token')";
	if(emailExist($email,$phone,$conn)){
		echo "Email or phone number already exist";
	}
	else{
		if($result=$conn->query($sql)){
			echo "User Registeration Successful";
		}
		else{
			echo "Registeration Failed";
		}
	}
	
}
else{
	echo "Insecure Connection";
}
