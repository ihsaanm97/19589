<?php
	include_once("db.php");

	$db = new mysqli($h, $u, $p, $d);
	if($db->connect_errno>0){
		die('Can not connect to Db '. $db->connect_error);
	}
	else
	{
		$s = $db->prepare('select collegeid, cname from college');
		if($s->execute())
		{
			$s->bind_result($i,$n);
			while($s->fetch())
			{
				$college[] = array('cid'=>$i, 'cname'=>$n);
			}
			$s->free_result();
			$s->close();
			echo json_encode(array('serverres'=>$college));
		}
		else
		{
			die('Error while fetching college names.');
		}
		$db->close();
	}
?>