<?php

include("db.php");
$conn = new mysqli($h, $u, $p, $d);

function checkToken($token,$conn){

	$query = "SELECT token FROM users;";
	$result = $conn->query($query);
	while($row = $result->fetch_assoc()){
		if($token==$row['token']){
			return true;
		}
	}
	return false;
}

if(isset($_GET['check'])){

	$token = $conn->real_escape_string($_POST['token']);
	if(checkToken($token,$conn)){
		echo "Done";
	}
	else{
		echo "Failed";
	}

}

