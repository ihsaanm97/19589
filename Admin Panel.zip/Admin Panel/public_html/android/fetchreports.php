<?php

include("db.php");
$conn = new mysqli($h,$u,$p,$d);


if (isset($_GET['notice'])){
	$jsondata = array();
	$sql = "select * from college,notices where college.collegeid = notices.collegeid";

	$result = $conn->query($sql) or die("cannot execute");

	while($row = $result->fetch_assoc()){
		$jsondata[] = $row;

	}
	echo json_encode(array("serverres"=>$jsondata));

}