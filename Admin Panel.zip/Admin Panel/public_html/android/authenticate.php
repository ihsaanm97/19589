<?php

include("db.php");

$conn = new mysqli($h,$u,$p,$d);

function authenticate($email,$pass,$conn){

		$sql = "select email,password from users;";
		$result = $conn->query($sql) or die("cannot execute");

		while($row = $result->fetch_assoc()){
			if($email == $row['email'] && $pass === $row['password']){
				
				return true;
			}
		}
		return false;
}
function getKey($email,$pass,$conn){

		$sql = "select email,password,token from users;";
		$result = $conn->query($sql) or die("cannot execute");

		while($row = $result->fetch_assoc()){
			if($email == $row['email'] && $pass === $row['password']){
				
				return $row['token'];
			}
		}
		return '';
}

	if(isset($_GET['authenticate'])){
		$email = $_POST['email'];
		$pass = $_POST['password'];
		if(authenticate($email,$pass,$conn)){
			$token = getKey($email,$pass,$conn);
			echo $token;
		}
		else{
			echo "Failed";
		}
	}

	
?>