<?php
	include('db.php');
    // If the values are posted, insert them into the database.
	
	$connection = new mysqli($h,$u,$p,$d);

	function addlike($repid,$conn){
		$sql = "update reports set likes = likes + 1 where repid=$repid";
		$result = $conn->query($sql);
		if($result){
			return true;
		}
		else{
			return false;
		}

	}

	function likeExist($token,$repid,$connection){
		$sql = "select token, repid from user_like";
		$result = $connection->query($sql);
		while($row = $result->fetch_assoc()){
			if($token==$row['token'] && $repid==$row['repid']){
				return true;
			}

		}
		return false;
	}

	if (isset($_GET['token']) && isset($_GET['reportid'])){

        $token = $_GET['token'];
		$reportid = $_GET['reportid'];
	    $query = "INSERT IGNORE INTO user_like VALUES (null,'$token','$reportid')";

	    if(!likeExist($token,$reportid,$connection)){
	    	addlike($reportid,$connection);
	    	$result = $connection->query($query);

			if($result){
				echo "pass";
			}
			else{
				echo "failed";
			}
	    }else{
	    	echo "Already Liked";
	    }
		

	}
?>