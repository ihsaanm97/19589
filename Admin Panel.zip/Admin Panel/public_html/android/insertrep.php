<?php
	
	include("db.php");
	$connect = new mysqli($h,$u,$p,$d);

	if(isset($_GET['token'])){
		$token = $_GET['token'];
		createEmp($connect,$token);
	}

	function authenticateToken($token){
		$sql = "SELECT password FROM users where token=$token";
		$result = $conn->query($sql) or die("cannot execute");

		while($row=$reult->fetch_assoc()){

			if($token==$row['token']){

				return true;

			}

		}
		return false;

	}

	function createEmp($connect,$token)
	{
		global $connect;

		$Type = $_POST['Type'];
		$Venue = $_POST['venue'];
		$Description = $_POST['description'];
		$mainType = $_POST['MainType'];
		

		$DefaultId = 0;
 
 		$ImageData = $_POST['Imagepath'];
		//$ImageName = $_POST['image_name'];

 		$GetOldIdSQL ="SELECT repid FROM reports ORDER BY repid ASC";
  
		$Query = mysqli_query($connect,$GetOldIdSQL);
 
		while($row = mysqli_fetch_array($Query)){
		 
			$DefaultId = $row['repid'];
		}

		$ImagePath = "images/$DefaultId.png";
		$ServerURL = "http://campuscompanion.000webhostapp.com/android/$ImagePath";

		$Date = getdate();
		$time = gettimeofday();
		
				$query = "INSERT INTO reports VALUES (null, '$token', '$Type',null, ' $Description' ,'$Venue','$ServerURL','In progress','$mainType',0,'fedded');";
 
		 
		if(mysqli_query($connect, $query)){

			file_put_contents($ImagePath,base64_decode($ImageData));
			echo "Your Image Has Been Uploaded.";
		}
		
		else{
		 	echo "Not Uploaded";
		}

		mysqli_close($connect);
	}
?>