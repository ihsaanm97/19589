<?php

include("db.php");
$conn = new mysqli($h,$u,$p,$d);

if(isset($_GET['trending'])){

	$sql = "SELECT * FROM reports WHERE maintype != 'personal' ORDER BY likes DESC";
	$fetch = array();
	$result = $conn->query($sql) or die("cannot execute");

	while($row = $result->fetch_assoc()){

		$fetch[] = $row; 

	}

	echo json_encode(array("serverres"=>$fetch));


}
else if(isset($_GET['token'])){
	$token = $_GET['token'];
	$sql = "SELECT * FROM reports WHERE token = '$token' ORDER BY likes DESC";
	$fetch = array();
	$result = $conn->query($sql) or die("cannot execute");

	while($row = $result->fetch_assoc()){

		$fetch[] = $row; 

	}

	echo json_encode(array("serverres"=>$fetch));


}
else{

	$sql = "SELECT * FROM reports ORDER BY repid DESC";
	$fetch = array();
	$result = $conn->query($sql) or die("cannot execute");

	while($row = $result->fetch_assoc()){

		$fetch[] = $row; 

	}

	echo json_encode(array("serverres"=>$fetch));
}


?>