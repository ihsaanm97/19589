<?php
	//$cid = json_decode($_POST['cid']);
	$cid = $_POST['cid'];//from android app upon selecting college
	include_once("db.php");

	$db = new mysqli($h, $u, $p, $d);
	if($db->connect_errno>0){
		die('Can not connect to Db '. $db->connect_error);
	}
	else
	{
		$s = $db->prepare('select deptid,deptname from department');
		if($s->execute())
		{
			$s->bind_result($i,$n);
			while($s->fetch())
			{
				$depts[] = array('did'=>$i, 'dname'=>$n);
			}
			$s->free_result();
			$s->close();
			echo json_encode(array('serverres'=>$depts));
		}
		else
		{
			die('Error while fetching department.');
		}
		$db->close();
	}
?>