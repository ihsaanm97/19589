<?php

		$h = "localhost";
		$u = "id5164310_root";
		$p = "sik123";
		$d = "id5164310_campus_companion";

?>