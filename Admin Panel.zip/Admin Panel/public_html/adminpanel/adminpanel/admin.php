<?php
include("header.php");
?>
<head>

</head>
           
        <div id="wrapper" style="margin-top:5%;">

            <!-- Navigation -->
			<div class="formblock">
			<form action="process_college_reg.php" name="college_reg" method="post" >
 
 <p><b>College Registration</b>	</p>
  <div class="container">
   
    <label for="cname"><b>College Name</b></label>
    <input type="text" placeholder="Enter colege name" name="cname" required>
	
	<label for="caddr"><b>College address</b></label>
	<input type="text" placeholder="Enter college address" name="caddr" required>
	
	
	<label for="ctype" name="uname"><b> College Type:
 	<select name="ctype">
	<option value="Engineering">Engineering</option>
	<option value="Medical">Medical</option>
	<option value="Other">Other</option>
	
	</select></b>
	</label>
	<br>
    
	
	<label for="contact"><b>College Contact</b></label>
    <input type="text" pattern="[1-9]{1}[0-9]{9}"  placeholder="Enter Contact number" name="contact" required>

 

    <button type="submit">Submit</button>
   
  </div>
   
  <div class="container" style="background-color:#f1f1f1">
    
    
  </div>
</form>
</div>

            

        </div>
        <!-- /#wrapper -->


    </body>
</html>
