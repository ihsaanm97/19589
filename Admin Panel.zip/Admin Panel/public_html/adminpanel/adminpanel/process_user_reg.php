<?php
	require('connect.php');
    // If the values are posted, insert them into the database.
    if (isset($_POST['first_name']) && isset($_POST['password'])){
        $first_name = mysqli_real_escape_string($connection,$_POST['first_name']);
		$last_name = mysqli_real_escape_string($connection,$_POST['last_name']);
	    $email = mysqli_real_escape_string($connection,$_POST['email']);
        $password = md5($_POST['password']);
		$conf_password = md5($_POST['conf_password']);
		if($password == $conf_password){
	       $query = "INSERT INTO `user_reg` (first_name,last_name, password, conf_password, email) VALUES ('$first_name','$last_name', '$password','$conf_password', '$email')";
				$result = mysqli_query($connection, $query);
        if($result){
            $smsg = "User Created Successfully.";
        }else{
            $fmsg ="User Registration Failed";
        }
		}else{
			$msg_failed="Password not matching";
		}
		
 
     
    }
    ?>