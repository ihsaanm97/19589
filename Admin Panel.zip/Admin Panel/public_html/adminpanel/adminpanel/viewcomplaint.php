<?php
		require('connect.php');
		
		
		
		if(isset($_GET['uid'])){
			
			
			$id = $_GET['uid'];
			$sql="SELECT * FROM users, reports where users.token = reports.token AND repid=$id;";
			$res = $connection->query($sql);
			
			
				
			while($row=$res->fetch_assoc()){?>
				
				
			
<?php
	include("header.php");
	?>
	<style>
	.block1{
		
		height:500px;
		width:100%;
		background-color:#4CAF50;
		color: white;
		padding: 14px 20px;
		margin: 8px 0;
		border: solid black 2px;
	}
	li{
		    font-family: 'Segoe UI', Tahoma, sans-serif;
	}
	</style>
	
<div id="wrapper" style="margin:8% 0 20% 20%; width:50%;">
			<div class="block1"ul>
			
			<li><b>Content:</b> <?php	echo $row["content"];?></li>	
			<li><b>location:</b>	 <?php	echo $row["location"];?></li>	
			
			<li><b>Upvotes:</b>	 <?php echo $row["likes"];?></li>
			<li><b>Media:</b>		 <img src="<?php echo $row["imageurl"]; ?>" /></li>
			</ul>			
			
			<form method="post">
			<?php
			if(isset($_POST['feedb'])){
			$feedb=$_POST['feedb'];
			echo "<script>alert('$id');</script>";
			$query = "UPDATE reports SET feedb = '$feedb' WHERE repid=$id";
			$result = $connection->query($query) or die("cannot exec");
        if($result){
            $smsg = "feedback submitted.";
        }else{
            $fmsg ="submission failed";
        }
		}
			?>
			<?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>
            <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
			<?php
				echo "<textarea rows='7' placeholder='Enter your feedback' name='feedb'  style='color:black;'></textarea>";
				echo  "<button type='submit' name='button.?php uid='".$row['repid']."'>submit</button>";
				?>
			</form>
			</div>
				


			
				
				
				<?php
				}
					
			}
			
			
			
		
			
		    
			



?>