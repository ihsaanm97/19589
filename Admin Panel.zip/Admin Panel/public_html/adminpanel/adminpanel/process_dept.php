<?php
	$h = "localhost";
	$u = "id5164310_root";
	$p = "sik123";
	$d = "id5164310_campus_companion";

	$db = new mysqli($h, $u, $p, $d);
	if($db->connect_errno>0){
		die('Can not connect to Db '. $db->connect_error);
	}
	else
	{
		$id='';
		$cid='0';//from user login (college id)
		$dname = $_POST['deptname'];

		$s = $db->prepare('insert into department values(?,?,?)');
		$s->bind_param('sss',$id,$cid,$dname);
		if($s->execute())
		{
			echo 'Department inserted.';
		}
		else
		{
			echo 'Error while inserting department.';
		}
		$db->close();
	}
?>