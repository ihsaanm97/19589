<?php
	
	$h = "localhost";
	$u = "root";
	$p = "sik123";
	$d = "campus_companion";

	$db = new mysqli($h, $u, $p, $d);
	if($db->connect_errno>0){
		die('Can not connect to Db '. $db->connect_error);
	}
	else
	{
		$name = $_POST['cname'];
		$addr = $_POST['caddr'];
		$ctype = $_POST['ctype'];
		$ccontact = $_POST['contact'];
		$id='';

		$s = $db->prepare('insert into college values(?,?,?,?,?)');
		$s->bind_param('sssss',$id,$name,$addr,$ctype,$ccontact);
		if($s->execute())
		{
			$smsg = "college Created Successfully.";
		}
		else
		{
			$fmsg ="College Registration Failed";
		}
		$db->close();
	}
?>