<?php
	require('connect.php');
    // If the values are posted, insert them into the database.
	print_r($_POST);
    if (isset($_POST['first_name']) && isset($_POST['password'])){
        $first_name = mysqli_real_escape_string($connection,$_POST['first_name']);
		$last_name = mysqli_real_escape_string($connection,$_POST['last_name']);
	    $email = mysqli_real_escape_string($connection,$_POST['email']);
        $password = $_POST['password'];
		$conf_password = $_POST['conf_password'];
		if($password == $conf_password){
	       $query = "INSERT INTO user_reg (first_name,last_name, password, conf_password, email) VALUES ('$first_name','$last_name', '$password','$conf_password', '$email')";
			
			$result = mysqli_query($connection, $query);
        if($result){
            $smsg = "User Created Successfully.";
        }else{
            $fmsg ="User Registration Failed";
        }
		}else{			
			$msg_failed="Password not matching";
		}
		
 
     
    }
    ?>
<?php
	include("mainheader.php");
	?>

						<p><b>User Registration</b></p>
			<div id="wrapper" style="margin-left:20%; width:50%;">
                 <div class="formblock">
						<div class="container" style="width:100%; height:70%; background-color:#f1f1f1;">
                               <form   method="POST" style="text-align:center;">
							                          <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>
                                                      <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
							         

                                 
                                        <label for="first_name">First Name</label>
                                        <input type="text" name="first_name" id="first_name" placeholder="" required="1" class="form-control" value="<?php if(isset($first_name) && !empty($first_name)){echo $first_name;} ?>">
                                    
                                        <label for="last_name">Last Name</label>
                                        <input type="text" name="last_name" id="last_name" placeholder="" required="1" class="form-control" value="<?php if(isset($last_name) && !empty($last_name)){echo $last_name;} ?>">
                                  
                                        <label for="email">Email-id</label>
                                        <input type="email" name="email" id="email" placeholder="" class="form-control" required="1" value="<?php if(isset($email) && !empty($email)){echo $email;} ?>">
                                 
                                        <label for="password">Password</label>
                                        <input type="password" name="password" id="password" placeholder="" class="form-control">
                                    
                                        <label for="conf_password">Confirm Password</label>
                                        <input type="password" name="conf_password" id="conf_password" placeholder="" class="form-control">
                                    
									     
										    <?php if(isset($msg_success)){ ?><div class="alert alert-success" role="alert"> <?php echo $msg_success; ?> </div><?php } ?>
                                            <?php if(isset($msg_failed)){ ?><div class="alert alert-danger" role="alert"> <?php echo $msg_failed; ?> </div><?php } ?>
                                   
                                    
                                       
                                            <button type="submit">submit</button>
											<span class="psw">Already a member? <a href="user_login.php">login</a></span>
                                     
                                 </form>   
                                </div>
                            
				    </div>
			</div>
</body>
</html>