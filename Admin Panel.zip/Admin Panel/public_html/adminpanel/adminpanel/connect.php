n<?php
$connection = mysqli_connect('localhost', 'id5164310_root', 'sik123');
if (!$connection){
    die("Database Connection Failed" . mysqli_error($connection));
}
$select_db = mysqli_select_db($connection, 'id5164310_campus_companion');
if (!$select_db){
    die("Database Selection Failed" . mysqli_error($connection));
}