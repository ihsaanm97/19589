<?php
	require('connect.php');
    // If the values are posted, insert them into the database.
	
    if (isset($_POST['deptname'])){
        $deptname = mysqli_real_escape_string($connection,$_POST['deptname']);
	
       
	       $query = "INSERT INTO department (deptname) VALUES ('$deptname')";
			
			$result = mysqli_query($connection, $query);
        if($result){
            $smsg = "User Created Successfully.";
        }else{
            $fmsg ="User Registration Failed";
        }
		
	
		
 
     
    }?>
	<?php
	include("header.php");
	?>
<body onload='document.form1.text1.focus()' style="margin-top:5%;">

<div class="formblock">
<form name="form1" method="post">
    
    	<?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>
        <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
 
				<p><b>Department</b>	</p>
  <div class="container" style="width:100%; background-color:#f1f1f1;">
	
    
    <label for=""><b>Department:</b></label>
    <input type="deptname" name="deptname"  required>
	
	<button type="submit">Submit</button>

  
   
  
    
    
  </div>
</form>
</div>
</body>
</html>