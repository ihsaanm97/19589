<?php
	require('connect.php');
    // If the values are posted, insert them into the database.
	
    if (isset($_POST['cname']) && isset($_POST['ctype'])){
        $cname = mysqli_real_escape_string($connection,$_POST['cname']);
		$ctype = mysqli_real_escape_string($connection,$_POST['ctype']);
	    $caddr = mysqli_real_escape_string($connection,$_POST['caddr']);
		$cont = mysqli_real_escape_string($connection,$_POST['cont']);
       
	       $query = "INSERT INTO college (cname,ctype,caddr,cont) VALUES ('$cname','$ctype', '$caddr','$cont')";
			
			$result = mysqli_query($connection, $query);
        if($result){
            $smsg = "User Created Successfully.";
        }else{
            $fmsg ="User Registration Failed";
        }
		
	
		
 
     
    }
    ?>

	
	<?php
	include("header.php");
	?>



           
               
     <div id="wrapper" style="margin-top:5%;">
    
<div class="formblock">
<form  method="post" >
					<?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>
                    <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
 
 <p><b>College Registration</b>	</p>
  <div class="container">
   
    <label for="cname"><b>College Name</b></label>
    <input type="text" placeholder="Enter colege name" name="cname" required>
	
	<label for="caddr"><b>College address</b></label>
	<input type="text" placeholder="Enter college address" name="caddr" required>
	
	
	<label for="ctype" name="uname"><b> College Type:
 	<select name="ctype">
	<option value="Engineering">Engineering</option>
	<option value="Medical">Medical</option>
	<option value="Other">Other</option>
	
	</select></b>
	</label>
	<br>
    
	
	<label for="cont"><b>College Contact</b></label>
    <input type="text" pattern="[1-9]{1}[0-9]{9}"  placeholder="Enter Contact number" name="cont" required>

 

    <button type="submit">Submit</button>
   
  </div>
   
  <div class="container" style="background-color:#f1f1f1">
    
    
  </div>
</form>
</div>

        </div>
        <!-- /#wrapper -->

        

</body>
</html>