<?php
	$h = "localhost";
	$u = "root";
	$p = "sik123";
	$d = "campus_companion";

	$db = new mysqli($h, $u, $p, $d);
	if($db->connect_errno>0){
		die('Can not connect to Db '. $db->connect_error);
	}
	else
	{
		$id='';
		$cid='0';//from user login (college id)
		$did=$_POST['deptname'];
		$notice = $_POST['notice'];
		$ndate = date('Y-m-d H:i:s');

		$s = $db->prepare('insert into notices values(?,?,?,?,?)');
		$s->bind_param('sssss',$id,$cid,$did,$notice,$ndate);
		if($s->execute())
		{
			echo 'Notice inserted.';
		}
		else
		{
			echo 'Error while inserting notice.';
		}
		$db->close();
	}
?>