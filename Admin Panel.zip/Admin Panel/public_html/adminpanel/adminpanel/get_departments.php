<?php
	$h = "localhost";
	$u = "id5164310_root";
	$p = "sik123";
	$d = "id5164310_campus_companion";

	$db = new mysqli($h, $u, $p, $d);
	if($db->connect_errno>0){
		die('Can not connect to Db '. $db->connect_error);
	}
	else
	{
		$cid='0';//from login
		$s = $db->prepare('select deptid,deptname from department where collegeid=?');
		$s->bind_param('s',$cid);
		if($s->execute())
		{
			$s->bind_result($i,$n);
			while($s->fetch())
			{	
				echo '<option value="'.$i.'">'.$n.'</option>';
			}
		}
		else
		{
			die('Error while fetching department.');
		}
		$db->close();
	}
?>