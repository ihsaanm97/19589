<?php
	include("header.php");
	?>


<body onload='document.form1.text1.focus()'>
<div id="wrapper" style="margin-top:5%;">

<div class="formblock">
<form action="./process_notices.php" name="notice" method="post">
 

  <div class="container">
		<p><b>Notice</b></p>
    
  
	
	<label for="deptname" name="deptname"><b>Department:
 	<select name="deptname">
    <?php
    	include_once('get_departments.php');
    ?>
	</select></b>
	</label>
	<br>
	
	<label for="notice"><b>Notice</b></label>
	<textarea  rows="7" cols="50" placeholder="Enter New Notice" name="notice" required ></textarea>
	
	<button type="submit">Submit</button>

  
   
				<div class="container" style="background-color:#f1f1f1">
    
    
				</div>
	</div>
		</form>
	</div>
	</div>
</body>
</html>