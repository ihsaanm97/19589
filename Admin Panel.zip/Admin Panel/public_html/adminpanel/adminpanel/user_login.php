<?php
  session_start();
  require_once('connect.php');
 
  if(isset($_POST['email']) & !empty($_POST['password'])){
		  $email =  $_POST['email'];
		  $password = $_POST['password'];
	  $query = "SELECT * FROM user_reg WHERE email='$email' AND password='$password'"; 
	  $result=mysqli_query($connection, $query);
	  $count=mysqli_num_rows($result);
	  if($count == 1){
		  $_SESSION['email'] = $email;
		  echo "<script> window.location.assign('dept.php'); </script>";
          }else{
			   $fmsg ="Invalid email/password";
		  }
	  
  }
 
    if (isset($_SESSION['email'])){
$email = $_SESSION['email'];
 
echo "<a href='logout.php'>Logout</a>";
unset($_SESSION['email']);
 }

    ?>
	
<?php
	include("mainheader.php");
	?>          
     <div id="wrapper" style="margin:5% 0 0 30%; width:50%;">
    <div class="formblock">
    
 
 <p><b>Login</b></p>
  <div class="container" style="width:100%; background-color:#f1f1f1;">
        
						<form  method="post" >
						<?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
						
						<label for="email">Email-id</label>
                        <input type="email" name="email" id="email" placeholder=""onSubmit="ValidateEmail(document.form1.text1)" />
                                 
                        <label  for="password">Password</label>
                        <input type="password" name="password" id="password" placeholder="" class="form-control"/>
                           <button  type="submit">Login</button>
						   
						   <span class="psw">Click here to <a href="user_reg.php">Register</a></span>
                            </form>
 

 
   
  </div>
</div>
  </div>
        

</body>
</html>