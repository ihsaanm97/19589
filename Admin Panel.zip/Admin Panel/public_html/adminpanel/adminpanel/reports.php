<?php
		require('connect.php');
	
		 $sql = 'SELECT * 
		FROM reports,users where users.token=reports.token';
		
			$query = mysqli_query($connection, $sql);
			
			if(isset($_POST['feedb'])){
				$feedb=$_POST['feedb'];
				$query="INSERT INTO reports(feedb)VALUES('$feedb')";
				$result=mysqli_query($connection,$query);
			}


?>
<?php
	include("header.php");
	?>
	
<div id="wrapper" style="margin:8% 0 20% 20%; width:50%;">
 <p><b>Reports</b></p>
<table id="customers">
  <thead>
  <tr>
	 <th>Report Id</th>
    <th>UserName</th>
    <th>Type</th>
    <th>Complaint</th>
	<th>Complaint Details</th> 
	<th>Date</th>
	<th>Delete</th>
  </tr>
  </thead>
     <tbody>
        <?php
		$repid	= 0;
          while ($row = mysqli_fetch_array($query)){
          echo '<tr>
					<td>'.$repid.'</td>
					<td>'.$row['name'].'</td>
					<td>'.$row['maintype'].'</td>
					<td>'.$row['content'].'</td>
					<td> <a href="viewcomplaint.php?uid='.$row['repid'].'">click to view details</a></span></td>
					<td>'. date('F d, Y', strtotime($row['rdate'])) . '</td>
					
				</tr>';
		  $repid++;}
        ?>
      </tbody>


  
</table>
</div>

</body>
</html>